<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');

class ChristmaslistModelMylist extends JModel
{
	private $data;

	function getData()
	{
		if (!isset($this->data))
		{
			$user =& JFactory::getUser();
			$query = 'SELECT * FROM #__christmaslist_items WHERE userid = ' . $user->id;
			
			$items = $this->_getList($query);
						
			foreach ($items as &$item) {
				$item->editlink = JRoute::_('index.php?option=com_christmaslist&view=item&id=' . $item->id);
				$item->notes = preg_replace('#(https?://\S+)#', '<a href="\1">\1</a>', $item->notes);
			}
			
			$this->data = $items;
		}

		return $this->data;
	}
}