<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.model');

class ChristmaslistModelOtherlists extends JModel
{
	private $data;
	private $users;
	private $buyers;
	
	function getData()
	{
		if (!isset($this->data))
		{
			$user =& JFactory::getUser();
			$query = 'SELECT * FROM #__christmaslist_items WHERE userid != ' . $user->id;
			
			$items = $this->_getList($query);
			
			$buyers = $this->getBuyers();
			
			// create buy links and regular links
			foreach ($items as &$item) {
				
				if (isset($buyers[$item->id]) && in_array($user->id, array_keys($buyers[$item->id]))) {
					$item->buylink = JRoute::_('index.php?option=com_christmaslist&task=unbuy&id=' . $item->id . '&' . JUtility::getToken() . '=1');
					$item->canbuy = false;
				} else {
					$item->buylink = JRoute::_('index.php?option=com_christmaslist&task=buy&id=' . $item->id . '&' . JUtility::getToken() . '=1');
					$item->canbuy = true;
				}
				
				$item->notes = preg_replace('#(https?://\S+)#', '<a href="\1">\1</a>', $item->notes);
			}
						
			$sorted = array();
			$users = $this->getUsers();
			
			foreach ($items as &$item) {
				$name = $users[$item->userid];
				
				if (isset($buyers[$item->id])) {
					$item->buyers = implode(', ', $buyers[$item->id]);
				} else {
					$item->buyers = '';
				}
				
				$sorted[$name][] = $item;
			}
			
			$this->data = $sorted;
		}

		return $this->data;
	}
	
	public function getUsers()
	{
		if (!isset($this->users)) {
			$query = 'SELECT id, name FROM #__users';

			$userlist = $this->_getList($query);

			$this->users = array();

			foreach ($userlist as $user) {
				$this->users[$user->id] = $user->name;
			}	
		}
		
		return $this->users;
	}
	
	public function getBuyers()
	{
		if (!isset($this->buyers)) {
			$query = 'SELECT b.itemid, u.name, u.id FROM #__christmaslist_buyers AS b LEFT JOIN #__users AS u ON u.id = b.buyerid ';

			$buyerlist = $this->_getList($query);
			
			$this->buyers = array();
			
			foreach ($buyerlist as $item) {
				$this->buyers[$item->itemid][$item->id] = $item->name;
			}
		}
		
		return $this->buyers;
	}
}