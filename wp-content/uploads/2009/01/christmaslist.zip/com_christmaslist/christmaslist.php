<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

JTable::addIncludePath(JPATH_COMPONENT . DS . 'tables');

class ChristmaslistController extends JController
{
	function save()
	{
		JRequest::checkToken() or jexit( 'Invalid Token' );
		
		$user =& JFactory::getUser();
		
		$row =& JTable::getInstance('items', 'Table');
		$row->bind(JRequest::get('post'));
		$row->userid = $user->id;
		
		if ($row->id) {
			$msg = 'Changes saved.';
		} else {
			$msg = 'Item added.';
		}
		
		$row->store();
		
		$this->setRedirect(JRoute::_('index.php?option=com_christmaslist&view=mylist'), $msg);
	}
	
	function buy()
	{
		JRequest::checkToken( 'get' ) or jexit( 'Invalid Token' );
		
		$id = JRequest::getInt('id', 0);
		$user =& JFactory::getUser();
		
		$row =& JTable::getInstance('buyers', 'Table');
		$row->itemid = $id;
		$row->buyerid = $user->id;
		$row->store();
		
		$row =& JTable::getInstance('items', 'Table');
		$row->load($id);
		
		$this->setRedirect(JRoute::_('index.php?option=com_christmaslist&view=otherlists'), 'I have you down for ' . $row->name . '. Good choice!');
	}

	function unbuy()
	{
		JRequest::checkToken( 'get' ) or jexit( 'Invalid Token' );
		
		$database =& JFactory::getDBO();
		$user =& JFactory::getUser();
		$id = JRequest::getInt('id', 0);
		
		$database->setQuery("DELETE FROM #__christmaslist_buyers WHERE buyerid = '{$user->id}' AND itemid = '{$id}'");
		$database->query();

		$row =& JTable::getInstance('items', 'Table');
		$row->load($id);
		
		$this->setRedirect(JRoute::_('index.php?option=com_christmaslist&view=otherlists'), 'Crossed you off for ' . $row->name . '... grinch.');
	}

	function display()
	{
		$view = JRequest::getVar('view', '');
		
		if ($view == '') {
			JRequest::setVar('view', 'mylist');
		}
		
		parent::display();
	}
}

$user =& JFactory::getUser();

if (!$user->id) {
	global $mainframe;
	
	$mainframe->redirect('index.php', 'No peeking! You have to log in first.');
}

$controller = new ChristmaslistController();
$controller->execute(JRequest::getCmd('task'));
$controller->redirect();