<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class ChristmaslistViewMylist extends JView
{
	function display($tpl = null)
	{
		$items = $this->get('data');
		
		$this->assignRef('items', $items);
		$this->assign('otherListsLink', JRoute::_('index.php?option=com_christmaslist&view=otherlists'));
		
		parent::display($tpl);
	}
}