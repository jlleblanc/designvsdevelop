<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );

$document =& JFactory::getDocument();
$document->addStyleSheet(JURI::base() . 'components/com_christmaslist/views/mylist/mylist.css');

?>

<h3>Your list</h3>

<table width="100%" id="itemList">
	<tr><th width="35%">Item</th><th>Notes (links to buy, etc...)</th><th> </th></tr>
	<?php foreach ($this->items as $item): ?>
		<tr><td><?= $item->name; ?></td> <td><?= $item->notes; ?></td> <td><a href="<?= $item->editlink ?>">edit</a></td></tr>
	<?php endforeach ?>
</table>
<p>&nbsp;</p>
<h3>Add to your list</h3>
<form action="index.php" method="post" id="addList">
	
	<p>
		<label><span>Item name:</span><input type="text" name="name" value="" /></label>
	</p>
	
	<p>
		<label><span>Item notes:</span><textarea name="notes" rows="8" cols="40"></textarea></label>
	</p>

	<p><input type="submit" value="Add"></p>
	<input type="hidden" name="option" value="<?= $option ?>" />
	<input type="hidden" name="task" value="save" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>

<p><a href="<?= $this->otherListsLink; ?>">Other lists</a></p>