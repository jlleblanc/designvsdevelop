<?php defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<form action="index.php" method="post" accept-charset="utf-8">
	
	<p><label>Item name:<input type="text" name="name" value="<?= $this->item->name ?>" /></label></p>
	<p><label>Item notes:<textarea name="notes" rows="8" cols="40"><?= $this->item->notes ?></textarea></label></p>
	
	<p><input type="submit" value="Submit"></p>
	<input type="hidden" name="id" value="<?= $this->item->id ?>" />
	<input type="hidden" name="option" value="<?= $option ?>" />
	<input type="hidden" name="task" value="save" />
	<?php echo JHTML::_( 'form.token' ); ?>
</form>