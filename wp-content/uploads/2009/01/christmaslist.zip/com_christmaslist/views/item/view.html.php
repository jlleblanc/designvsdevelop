<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class ChristmaslistViewItem extends JView
{
	function display($tpl = null)
	{
		$id = JRequest::getInt('id', 0);
		
		$item =& JTable::getInstance('items', 'Table');
		$item->load($id);
		
		$this->assignRef('item', $item);
		
		parent::display($tpl);
	}
}