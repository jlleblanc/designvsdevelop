<?php

defined( '_JEXEC' ) or die( 'Restricted access' ); 

foreach ($this->lists as $person => $wishes) {
	echo '<h3>' . $person . '</h3>';
	
	?>
	<table border="0" width="100%">
		<tr> <th>Item name</th> <th>Notes, where to buy, etc...</th> <th>Who's buying</th> </tr>
		<?php
		foreach ($wishes as $wish) {
			echo '<tr> <td>' . $wish->name . '</td> <td>' . $wish->notes . '</td> <td>' . $wish->buyers . '</td> <td> <a href="' . $wish->buylink . '">';
			
			if ($wish->canbuy) {
				echo 'Mark as buying';
			} else {
				echo 'Mark as not buying anymore';
			}
			
			echo '</a></td></tr>';
		}
		?>
	</table>
	<p>&nbsp;</p>
	<?php
}
?>
<a href="index.php?option=com_christmaslist&amp;view=mylist">&larr; Back to your list</a>