<?php 
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');

class ChristmaslistViewOtherlists extends JView
{
	function display($tpl = null)
	{
		$lists = $this->get('data');
		
		$this->assignRef('lists', $lists);
		
		parent::display($tpl);
	}
}