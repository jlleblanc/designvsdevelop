create table jos_christmaslist_items (
	id int(11) auto_increment not null,
	name varchar(255),
	userid int(11),
	notes text,
	
	primary key(id)
	);
	
create table jos_christmaslist_buyers (
	id int(11) auto_increment not null,
	buyerid int(11),
	itemid int(11),
	
	primary key(id)
	);