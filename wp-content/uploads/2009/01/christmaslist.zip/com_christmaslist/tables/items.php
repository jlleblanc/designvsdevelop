<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableItems extends JTable
{
	public $id = null;
	public $name = null;
	public $userid = null;
	public $notes = null;
	
	function __construct(& $db) {
		parent::__construct('#__christmaslist_items', 'id', $db);
	}
}