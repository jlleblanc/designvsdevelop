<?php
defined( '_JEXEC' ) or die( 'Restricted access' );

class TableBuyers extends JTable
{
	public $id = null;
	public $buyerid = null;
	public $itemid = null;
	
	function __construct(& $db) {
		parent::__construct('#__christmaslist_buyers', 'id', $db);
	}
}