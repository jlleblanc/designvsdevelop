CREATE TABLE `jos_christmaslist_buyers` (
  `id` int(11) NOT NULL auto_increment,
  `buyerid` int(11) default NULL,
  `itemid` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `buyerid` (`buyerid`,`itemid`)
);

CREATE TABLE `jos_christmaslist_items` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `userid` int(11) default NULL,
  `notes` text,
  PRIMARY KEY  (`id`)
);

